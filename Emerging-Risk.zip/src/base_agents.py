import os
import json
import re
from datetime import datetime
from typing import Dict, Any
from langchain_groq import ChatGroq
from src.config import PromptTemplate

class OpenAIResponse:
    def __init__(self, content: str, prompt_tokens: int, completion_tokens: int):
        self.content = content
        self.response_metadata = {
            "token_usage": {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": prompt_tokens + completion_tokens
            }
        }

class SimpleChatOpenAI:
    def __init__(
        self, 
        model: str, 
        api_key: str, 
        temperature: float = 0.0,
        azure_endpoint: str = None,
        azure_api_version: str = "2024-02-15-preview"
    ):
        self.model = model
        self.api_key = api_key
        self.temperature = temperature
        self.azure_endpoint = azure_endpoint
        self.azure_api_version = azure_api_version

    def invoke(self, prompt: str) -> OpenAIResponse:
        import urllib.request
        import json
        
        # Format URL and headers differently for Azure vs standard OpenAI
        if self.azure_endpoint:
            base_url = self.azure_endpoint.rstrip('/')
            url = f"{base_url}/openai/deployments/{self.model}/chat/completions?api-version={self.azure_api_version}"
            headers = {
                "Content-Type": "application/json",
                "api-key": self.api_key
            }
        else:
            url = "https://api.openai.com/v1/chat/completions"
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}"
            }
            
        data = {
            "messages": [{"role": "user", "content": prompt}],
            "temperature": self.temperature
        }
        
        # Model parameter is only required in standard OpenAI payload, defined in URL path for Azure
        if not self.azure_endpoint:
            data["model"] = self.model
        
        req = urllib.request.Request(
            url, 
            data=json.dumps(data).encode("utf-8"), 
            headers=headers,
            method="POST"
        )
        
        try:
            with urllib.request.urlopen(req, timeout=30) as response:
                resp_data = json.loads(response.read().decode("utf-8"))
                content = resp_data["choices"][0]["message"]["content"]
                usage = resp_data.get("usage", {})
                prompt_tokens = usage.get("prompt_tokens", 0)
                completion_tokens = usage.get("completion_tokens", 0)
                return OpenAIResponse(content, prompt_tokens, completion_tokens)
        except Exception as e:
            raise RuntimeError(f"LLM API call failed: {e}")

class BaseAgent:
    def __init__(self, config: Any, tracker: Any = None):
        self.config = config
        self.tracker = tracker

    def get_logger(self) -> Any:
        from src.utils.logger import get_agent_logger
        agent_name = getattr(self.config, 'name', self.__class__.__name__)
        return get_agent_logger(agent_name)

    def format_prompt(self, template: PromptTemplate, **kwargs) -> str:
        # Framework default variables
        now = datetime.now()
        framework_vars = {
            "current_year": str(now.year),
            "today_str": now.strftime("%Y-%m-%d"),
            "format_instructions": "Your output must be a single, valid JSON block. Do not include markdown ticks (like ```json), explanations, or notes."
        }
        
        # Merge prompt_vars from agent configuration if defined
        config_vars = {}
        if hasattr(self.config, 'prompt_vars') and self.config.prompt_vars:
            config_vars = self.config.prompt_vars
            
        merged = {**framework_vars, **config_vars, **kwargs}
        return template.format(**merged)

    def call_llm(self, prompt: str, temperature: float = 0.0) -> str:
        # Retrieve potential Azure OpenAI environment variables
        env_azure_key = os.environ.get("AZURE_OPENAI_API_KEY")
        env_azure_endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT") or os.environ.get("AZURE_OPENAI_API_BASE") or os.environ.get("OPENAI_API_BASE") or os.environ.get("OPENAI_BASE_URL")
        env_api_version = os.environ.get("AZURE_OPENAI_API_VERSION") or os.environ.get("OPENAI_API_VERSION") or "2024-02-15-preview"
        env_deployment_name = os.environ.get("AZURE_OPENAI_DEPLOYMENT") or os.environ.get("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME") or os.environ.get("DEPLOYMENT_NAME") or os.environ.get("OPENAI_MODEL") or "gpt-4o-mini"
        
        openai_key = os.environ.get("OPENAI_API_KEY")
        groq_key = os.environ.get("GROQ_API_KEY")
        
        # Check signs of Azure deployment
        is_azure = False
        if env_azure_key:
            is_azure = True
        elif os.environ.get("OPENAI_API_TYPE") == "azure":
            is_azure = True
        elif env_azure_endpoint and ("openai.azure.com" in env_azure_endpoint or "azure" in env_azure_endpoint.lower()):
            is_azure = True

        logger = self.get_logger()
        agent_name = getattr(self.config, 'name', self.__class__.__name__)
        logger.info(f"[{agent_name}] Invoking LLM for prompt/extraction...")
        logger.info(f"[{agent_name}] Prompt input sent to LLM:\n{prompt}")

        if is_azure:
            # For Azure, the effective API key could be standard OPENAI_API_KEY if AZURE_OPENAI_API_KEY is not set
            azure_key = env_azure_key or openai_key
            if not azure_key:
                raise ValueError("Azure OpenAI detected but no API key configured. Set AZURE_OPENAI_API_KEY or OPENAI_API_KEY.")
            if not env_azure_endpoint:
                raise ValueError("Azure OpenAI detected but no endpoint configured. Set AZURE_OPENAI_ENDPOINT or AZURE_OPENAI_API_BASE or OPENAI_API_BASE.")
                
            model_name = env_deployment_name
            try:
                from langchain_openai import AzureChatOpenAI
                llm = AzureChatOpenAI(
                    azure_endpoint="https://ai-trans-aio-resource.services.ai.azure.com",
                    api_key="6pNEN6ReosG5EckvoywwuLvFXns6ZwrkEhVX4BHp3Pse1llzI2kLJQQJ99CFACHYHv6XJ3w3AAAAACOGrkOJ",
                    api_version=env_api_version,
                    azure_deployment="Llama-4-Maverick-17B-128E-Instruct-FP8",
                )
            except ImportError:
                llm = SimpleChatOpenAI(
                    model=env_deployment_name,
                    api_key=azure_key,
                    temperature=temperature,
                    azure_endpoint=env_azure_endpoint,
                    azure_api_version=env_api_version
                )
        elif openai_key:
            model_name = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
            try:
                from langchain_openai import ChatOpenAI
                llm = ChatOpenAI(
                    model=model_name,
                    api_key=openai_key,
                    temperature=temperature
                )
            except ImportError:
                llm = SimpleChatOpenAI(
                    model=model_name,
                    api_key=openai_key,
                    temperature=temperature
                )
        elif groq_key:
            model_name = os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile")
            llm = ChatGroq(
                model=model_name,
                api_key=groq_key,
                temperature=temperature
            )
        else:
            raise ValueError(
                "No LLM credentials configured. Please set AZURE_OPENAI_API_KEY, OPENAI_API_KEY, or GROQ_API_KEY."
            )

        
        try:
            res = llm.invoke(prompt)
            prompt_tokens = 0
            completion_tokens = 0
            
            # Track token usage if tracker is present
            if hasattr(res, 'response_metadata') and res.response_metadata:
                token_usage = res.response_metadata.get('token_usage', {})
                if token_usage:
                    prompt_tokens = token_usage.get('prompt_tokens', 0)
                    completion_tokens = token_usage.get('completion_tokens', 0)
                    if self.tracker:
                        self.tracker.add_usage(prompt_tokens, completion_tokens)
            
            # Calculate cost estimate based on model type
            if azure_key or openai_key:
                if "gpt-4o-mini" in model_name:
                    input_rate = 0.15
                    output_rate = 0.60
                elif "gpt-4o" in model_name:
                    input_rate = 2.50
                    output_rate = 10.00
                else:
                    input_rate = 0.15
                    output_rate = 0.60
            else:
                input_rate = 0.59
                output_rate = 0.79
                
            cost = (prompt_tokens * input_rate + completion_tokens * output_rate) / 1000000.0
            
            # Log usage & outputs
            logger.info(f"[{agent_name}] LLM Response received. Usage: input={prompt_tokens}, output={completion_tokens}, reasoning=0, cached=0, tool_calls=0, cost=${cost:.6f}")
            logger.info(f"[{agent_name}] Output text:\n{str(res.content)}")
            
            return str(res.content)
        except Exception as e:
            import traceback
            logger.error(f"[{agent_name}] LLM invocation failed: {e}\nTraceback:\n{traceback.format_exc()}")
            raise RuntimeError(f"Error calling live model: {e}")

    def parse_json(self, text: str) -> Dict[str, Any]:
        cleaned = text.strip()
        # Clean any markdown code blocks
        if cleaned.startswith("```json"):
            cleaned = cleaned[7:]
        elif cleaned.startswith("```"):
            cleaned = cleaned[3:]
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
        cleaned = cleaned.strip()

        try:
            return json.loads(cleaned)
        except json.JSONDecodeError as e:
            # Fallback regex to find JSON object structure
            match = re.search(r"\{.*\}", cleaned, re.DOTALL)
            if match:
                try:
                    return json.loads(match.group(0))
                except json.JSONDecodeError:
                    pass
            raise ValueError(f"Failed to parse LLM output as JSON. Output was: {text}. Error: {e}")

class BaseCollectorAgent(BaseAgent):
    pass

class BaseCoordinatorAgent(BaseAgent):
    pass

class BaseFactCheckerAgent(BaseAgent):
    pass

class BaseUnderwriterAgent(BaseAgent):
    pass
